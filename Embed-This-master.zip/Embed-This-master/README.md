# Embed-This!
A simple Discord bot for embedding messages written in python.

### Setup
Download the files for the bot and make sure Python 3.6+ is installed.
After you have done those steps, simply install the following dependencies:
- discord.py
- pychalk

After this, open the bot file in an IDE or text editor and input your token and desired role.

As chalk is used, using Windows' CMD will not be recommended. If you're on a UNIX based OS the bash console works fine. To see the pretty colours in Windows, download and install ConEmu and use that as your terminal.

### Usage
The bot has a very simple set of commands.
- help: lists all commands.
- embed: embeds the text that follows the command, using the regular colour and your profile picture as the thumbnail.
- rembed: embeds the text that follows the command, using a specified colour (asked after the command is executed) and a specified thumbnail (asked after the colour is statesd).

### Using the code in your own projects
Use is permitted with credit, as long as `Made by Da532` is cited in the footer or something use is okay.
